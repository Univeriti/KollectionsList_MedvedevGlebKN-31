public class Main {
    public static void main(String[] args) {
        MyLinkedList list = new MyLinkedList();

        list.addLast(10);
        list.addLast(20);
        list.addFirst(5);
        list.add(2, 15);

        list.printList();

        System.out.println("Елемент за індексом 2: " + list.get(2));
        System.out.println("Розмір (size): " + list.getSize());

        list.remove(1);
        list.printList();

        list.clear();
        System.out.println("Розмір після очищення: " + list.getSize());
    }
}